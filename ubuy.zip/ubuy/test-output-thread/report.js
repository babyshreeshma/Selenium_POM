$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"2a4a52e8-cee7-46b0-b34d-9ba0523ddfec","feature":"Search Page Tests","scenario":"User clicking search button and going into the search result page","start":1695988321734,"group":1,"content":"","tags":"","end":1695988340446,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});