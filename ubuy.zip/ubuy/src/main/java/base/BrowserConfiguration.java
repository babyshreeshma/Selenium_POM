package base;

import java.util.Collections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class BrowserConfiguration {
    static WebDriver driver;

    public static WebDriver getBrowser() {
        EdgeOptions edgeOptions = new EdgeOptions();
        edgeOptions.setCapability("acceptInsecureCerts", true);
        edgeOptions.addArguments("--guest");
        edgeOptions.setExperimentalOption("useAutomationExtension", false);
        edgeOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
        driver = new EdgeDriver(edgeOptions);
        driver.manage().window().maximize();
        return driver;
    }
}

