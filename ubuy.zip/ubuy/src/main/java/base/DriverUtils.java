package base;

import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utilities.DateUtils;
import utilities.FileIO;

public class DriverUtils {
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	public DriverUtils() {
		prop = FileIO.initProperties();
	}

	/***************** invoke browser **************/
	public static WebDriver invokeBrowser() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("edge")) {
			driver = BrowserConfiguration.getBrowser();
		}
		return driver;
	}

	/***************** open website url **************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
	}

	/************* check if the element is present ********/
    public static boolean isElementPresent(WebElement element, Duration timeout) {
        try {
            new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private static boolean isAlertPresent() {
        try {
            // Attempt to switch to an alert
            driver.switchTo().alert();
            return true;
        } catch (Exception e) {
            // No alert found
            return false;
        }
    }// To clear an element
	// In this project the password was getting automatically filled so we have to use this to clear the pre-existing data
	public void clear(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//To get text
	public static String getText(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	// To send text
	public static void sendText(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To click on the elements
	public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**************** drop down handling *****************/
	public static void dropDownHandling(WebElement element, String value) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			Select s = new Select(element);
			s.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void takeScreenShot(String filePath) {
		try {
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// To retrieve the "value" attribute of an element after waiting for its presence
	public static String getAttributeValueWithWait(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			return element.getAttribute("value");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public static void scrollVertically(int pixels) {
	    try {
	        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
	        String script = "window.scrollBy(0, arguments[0])";
	        jsExecutor.executeScript(script, pixels);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	
	public void scrollElementIntoView(WebElement element) {
	    try {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'auto', block: 'center', inline: 'center'});", element);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	public static void switchToIframe(WebDriver driver, String iframeId) {
	    try {
	        driver.switchTo().frame(iframeId);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	public static void waitForElementToBeVisible(WebElement element, Duration timeout) {
	    try {
	        new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	public static Boolean waitTillElementToBeVisible(WebElement element, Duration timeout) {
        try {
            new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

	public static boolean waitTillElementToBeInvisible(WebElement element, Duration timeout) {
		try {
            new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
	public static void switchToAlertAccept() {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// Add this method to move over an element using Actions
    public static void moveOver(WebElement element) {
        try {
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String getAttributeValueWithWait(By locator) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15))
					.until(ExpectedConditions.presenceOfElementLocated(locator));
			return driver.findElement(locator).getAttribute("value");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
    public static void jsClick(WebElement element) {
        try {
            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
            jsExecutor.executeScript("arguments[0].click();", element);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delay(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}


}

