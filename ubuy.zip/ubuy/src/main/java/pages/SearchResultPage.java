package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;


public class SearchResultPage extends DriverUtils {
	WebDriver driver;

	public SearchResultPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//@FindBy(id = "chbx_ufulfilled")
	@FindBy(xpath="//div[contains(@class,\"input-checkbox\")]//input[@id=\"chbx_ufulfilled\"]")
	public WebElement checkbox;
	
	@FindBy(xpath="//div[@id=\"usstore-products\"]//div[1]//div//a//figure//img")
	public WebElement product1;

	@FindBy(xpath="//button[@id=\"add-to-cart-btn\"]")
	public WebElement addtocart;
	
	@FindBy(xpath="//div[contains(@class,\"btn-bg-block\")]//a[@id=\"add-to-cart-view-cart\"]")
	public WebElement viewCart;
	
	@FindBy(id="write-a-review")
	public WebElement review;
	
	@FindBy(id="write-customer-review")
	public WebElement testReview;
	
	@FindBy(id="search-box-text-sm")
	public WebElement srchInSrchPage;
	
	public void clickCheckbox() {
		clickOn(checkbox);
	}
	
	public void clickAProduct() {
		clickOn(product1);
	}
	
	public void clickAddToCart() {
		clickOn(addtocart);
	}
	
	public void clickViewCart() {
		clickOn(viewCart);
	}
	
	public void clickReview() {
		clickOn(review);
	}
	
	public void clickWriteReview() {
		clickOn(testReview);
	}
}