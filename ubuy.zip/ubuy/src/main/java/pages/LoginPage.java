package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class LoginPage extends DriverUtils {
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "login[username]")
	public WebElement uname;
	
	@FindBy(name = "login[password]")
	public WebElement password;
	
	@FindBy(id="login-form-btn")
	public WebElement login;

	public void sendDataToUname(String eml) {
		clear(uname);
		sendText(uname, eml);
	}
	
	public void sendDataToPassword(String pword) {
		clear(password);
		sendText(password, pword);
	}
	
	public void clickLogin() {
		clickOn(login);
	}
	
	public void clearUname() {
		clear(uname);
	}
	
	public void clearPword() {
		clear(password);
	}

}