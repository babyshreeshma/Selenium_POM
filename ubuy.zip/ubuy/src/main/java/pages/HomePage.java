package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class HomePage extends DriverUtils {
	WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "navbarDropdown")
	public WebElement explore;
	
	@FindBy(xpath="//div[@id=\"navbarDropdownthree\"]/span[2]")
	public WebElement account;
	
	@FindBy(xpath="/html/body/header/div/div[2]/div/nav/div[3]/ul/li[4]/ul/li[2]/a")
	public WebElement signIn;
	
	@FindBy(xpath="//div[contains(@class,\"new-to-ubuy\")]//div[contains(@class,pt-5)]//a")
	public WebElement createAccount;
	
	//@FindBy(name="q")
	@FindBy(xpath="//form[@id=\"search-form\"]//input[@name=\"q\"]")
	public WebElement search;
	
	@FindBy(xpath="//button[contains(@class,\"submit\")]")
	public WebElement searchSubmit;
	
	public void clickExploreButton() {
		moveOver(explore);
		clickOn(explore);
	}
	
	public void clickAccountButton() {
		clickOn(account);
	}
	
	public void clickSignInButton() {
		clickOn(signIn);
	}
	
	public void clickCreateAccountButton() {
		clickOn(createAccount);
	}
	
	public void clicksrch() {
		clickOn(search);
	}
	
	public void clickSearch(String text) {
		
		sendText(search,text);
		
		
	}
	
	public void clickSearchSubmitButton() {
		clickOn(searchSubmit);
	}
	
	


}
