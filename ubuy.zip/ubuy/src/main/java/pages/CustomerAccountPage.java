package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;


public class CustomerAccountPage extends DriverUtils {
	WebDriver driver;

	public CustomerAccountPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "/html/body/main/div/section/div/div/div/div[2]/div/ul/li[2]/a/div")
	public WebElement acntInfo;
	
	
	//@FindBy(id="acoount-manage")
	@FindBy(xpath="//div[@id=\"acoount-manage\"]//img")
	public WebElement acntmng;
	
	@FindBy(xpath="/html/body/header/div/div[2]/nav/div[3]/ul/li[3]/ul/li[5]/a")
	public WebElement logout;
	
	public void clickAcnt() {
		clickOn(acntInfo);
	}
	
	public void clickAcntMng() {
		clickOn(acntmng);
	}
	
	public void clickLogout() {
		clickOn(logout);
	}
	
	
	
	

}
