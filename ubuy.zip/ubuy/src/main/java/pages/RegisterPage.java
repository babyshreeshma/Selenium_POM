package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class RegisterPage extends DriverUtils {
	WebDriver driver;

	public RegisterPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "fullname")
	public WebElement fullname;

	@FindBy(id = "rmobile")
	public WebElement mobileno;

	@FindBy(name = "email")
	public WebElement email;

	@FindBy(id = "password")
	public WebElement password;

	@FindBy(id = "confirmation")
	public WebElement confirmation;
	
	
	
	@FindBy(xpath="//form[@id=\"new-user-create-form\"]//div[7]//label[@class=\"mb-0\"]")
	public WebElement agree;
	
	@FindBy(xpath="//span[@id=\"recaptcha-anchor\"]//div[2]")
	public WebElement captcha;
	
	
	//@FindBy(id="create-form-btn")
	//@FindBy(xpath="//div[contains(@class,\"justify-content-center\")]//button[@id=\"create-form-btn\"]")
	
	@FindBy(xpath="/html/body/main/div/section/div/div/div/div/div[2]/div[1]/form/div[9]/button")
	public WebElement crtAcnt;
	
	public void sendDataToFirstname(String fname) {

		sendText(fullname, fname);
	}

	public void sendDataToMobile(String mobile) {

		sendText(mobileno, mobile);
	}

	public void sendDataToEmail(String mail) {

		sendText(email, mail);
	}

	public void sendDataToPassword(String pword) {

		sendText(password, pword);
	}

	public void sendDataToConfirmpassword(String cpwrd) {

		sendText(confirmation, cpwrd);
	}
	
	public void clickCaptcha() {
		clickOn(captcha);
	}
	
	public void clickAgree() {
		clickOn(agree);
	}
	public void clickcrtAcnt() {
		clickOn(crtAcnt);
	}
	
	
	
	

}