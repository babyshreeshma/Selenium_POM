package testCases;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.CustomerAccountPage;
import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;
import pages.SearchResultPage;
import utilities.ExcelUtils;
import utilities.SampleListener;


@Listeners(SampleListener.class)
public class searchPageTests extends BaseTest {

    private HomePage homepage;
    private RegisterPage regpage;
    private LoginPage lgnpage;
    private CustomerAccountPage cacntpage;
    private SearchResultPage searchpage;

    @BeforeClass
    public void MainTest() {
    	homepage = new HomePage(driver);
    	regpage = new RegisterPage(driver);
    	lgnpage = new LoginPage(driver);
    	cacntpage = new CustomerAccountPage(driver);
    	searchpage = new SearchResultPage(driver);
    	
       // data = ExcelUtils.testdata();
    }

    /*********** Test case to search for a product. ************/

    @Test(priority = 0)
    public void searchPageTest() {
    	homepage = goToHomePage();
    	homepage.clickSearch("Saree");
    	
    	homepage.clickSearchSubmitButton();
    
    	String expectedUrl = "https://www.ubuy.co.in/search/?q=Saree";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
        
        
    }
    
    @Test(priority=1)
    public void chooseProductTest() throws InterruptedException {
    	searchpage.clickCheckbox();
    	searchpage.clickAProduct();
    	
  /*
    	String expectedUrl = "https://www.ubuy.co.in/product/EXERHYKOW-patola-saree-indian-saree-traditional-saree/?ref=list-es&uq=saree&ti=2713";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Thread.sleep(30000);
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");	
        
        */
    	
    	String expectedUrl = "https://www.ubuy.co.in/product/EXERHYKOW-patola-saree-indian-saree-traditional-";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Thread.sleep(30000);
        Assert.assertNotEquals(actualUrl, expectedUrl, "URLs do not match");
    	
    }
    
    //It is failed because website has some glitches
    @Test(priority=2)
    public void addToCartTest(){
    	searchpage.clickAddToCart();
    	searchpage.clickAddToCart();
    	Boolean isViewCartOptionDisplayed = DriverUtils.waitTillElementToBeVisible(searchpage.viewCart,
				Duration.ofSeconds(20));

		Assert.assertTrue(isViewCartOptionDisplayed, "Product added to the cart");
    	
    	
    }
    
    @Test(priority= 3)
    public void clickReview() {
    	searchpage.clickReview();
    	
    	
    	Boolean isWriteReviewDisplayed = DriverUtils.waitTillElementToBeVisible(searchpage.testReview,
				Duration.ofSeconds(20));

		Assert.assertTrue(isWriteReviewDisplayed, "write review is working");
    	
    }
    
    
    
    
    
}