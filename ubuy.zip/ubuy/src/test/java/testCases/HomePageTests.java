package testCases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.HomePage;
import pages.RegisterPage;
import utilities.SampleListener;


@Listeners(SampleListener.class)
public class HomePageTests extends BaseTest {

    private HomePage homepage;
    private RegisterPage regpage;

    @BeforeClass
    public void MainTest() {
    	homepage = new HomePage(driver);
    	regpage = new RegisterPage(driver);
 
    }

    /*********** Test case to create account ************/

    @Test(priority = 0)
    public void signInAccountClickTest() {
    	homepage = goToHomePage();
    	homepage.clickAccountButton();
    	homepage.clickSignInButton();
    
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/login";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
    }
   
    @Test(priority = 1)
    public void clickCreateAccountButtonTest() {
    	homepage.clickCreateAccountButton();
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/create/";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
    	
   	
    }
    
    @Test(priority = 1)
	public void userRegisterTest() {
		
		String fname = "Anu Mathwe";
		String email = "Anumathew@gmail.com";
		
		String mobile="9876567891";	
		
		String password = "Anum@1234";
		String confirmpassword = "Anum@1234";

		// Fill the register page
		regpage.sendDataToFirstname(fname);
		regpage.sendDataToEmail(email);
		regpage.sendDataToMobile(mobile);
		regpage.sendDataToPassword(password);
		regpage.sendDataToConfirmpassword(confirmpassword);
		
		regpage.clickCaptcha();
		regpage.clickAgree();
		

		String retrievedFirstName = regpage.fullname.getAttribute("value");
		String retrievedEmail = regpage.email.getAttribute("value");
		String retrievedMobile = regpage.mobileno.getAttribute("value");
		String retrievedPassword = regpage.password.getAttribute("value");
		String retrievedConfirmedPassword = regpage.confirmation.getAttribute("value");

		// Verify that retrieved values match the entered values
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(retrievedFirstName).isEqualTo(fname);
		softAssertions.assertThat(retrievedEmail).isEqualTo(email);
		softAssertions.assertThat(retrievedMobile).isEqualTo(mobile);
		softAssertions.assertThat(retrievedPassword).isEqualTo(password);
		softAssertions.assertThat(retrievedConfirmedPassword).isEqualTo(confirmpassword);
		softAssertions.assertAll();
		DriverUtils.delay(2000);
		regpage.clickcrtAcnt();
		// Verify that the correct URL is reached after clicking.
		 
		
	}

    
    

}
