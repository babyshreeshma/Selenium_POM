package testCases;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.CustomerAccountPage;
import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;
import utilities.ExcelUtils;
import utilities.SampleListener;


@Listeners(SampleListener.class)
public class LoginPageTests extends BaseTest {

    private HomePage homepage;
    private RegisterPage regpage;
    private LoginPage lgnpage;
    private CustomerAccountPage cacntpage;

    @BeforeClass
    public void MainTest() {
    	homepage = new HomePage(driver);
    	regpage = new RegisterPage(driver);
    	lgnpage = new LoginPage(driver);
    	cacntpage = new CustomerAccountPage(driver);
     
    }

    /*********** Test case to login ************/

    @Test(priority = 0)
    public void loginPageRedirectionTest() {
    	homepage = goToHomePage();
    	homepage.clickAccountButton();
    	homepage.clickSignInButton();
    
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/login";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
    }
   
    @Test(priority = 1)
    public void loginTest() {
    	lgnpage.sendDataToUname("anu@gmail.com");
    	lgnpage.sendDataToPassword("anu@12345");
    	lgnpage.clickLogin();
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/login/";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "Invalid username and password");
   	
    }
    @Test
	@DataProvider(name = "testdata")
	public Object[][] testDataLogin() {
		return ExcelUtils.testdata();

	}
    
	@Test(priority = 1, dataProvider = "testdata" )
    public void loginTest2(String username,String password) {
    	lgnpage.sendDataToUname(username);
    	lgnpage.sendDataToPassword(password);
    	lgnpage.clickLogin();
    	
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/login/";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        
        

	    if (username.equals("anu") && password.equals("1234")) {
	    	Assert.assertEquals(actualUrl, expectedUrl, "Invalid username and password");
	    } else if (username.equals("anu@gmai..com") && password.equals("1234")) {
	    	Assert.assertEquals(actualUrl, expectedUrl, "Invalid username and password");
	    } else if (username == null || password == null) {
	    	Assert.assertEquals(actualUrl, expectedUrl, "Invalid username and password");
	    }
    	
   	
    }
	   
    
    @Test(priority = 2)
    public void loginTest3() {
    	lgnpage.clearUname();
    	lgnpage.clearPword();
    	lgnpage.sendDataToUname("ammuthomas@gmail.com");
    	lgnpage.sendDataToPassword("Ammu@1234");
    	lgnpage.clickLogin();
    	
    		
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "login is done");
   	
    }
    
    
    @Test(priority=3)
    public void clickAccountInformationTest() {
    	cacntpage.clickAcntMng();
    	cacntpage.clickLogout();
    	
    	String expectedUrl = "https://www.ubuy.co.in/customer/account/login/";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "login is done");
   	
    }
    
    
    

}
