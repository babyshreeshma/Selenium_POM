package stepDefinitions;

import org.junit.BeforeClass;
import org.testng.Assert;

import base.BaseTest;
import base.DriverUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.SearchResultPage;

public class SearchSteps extends BaseTest {
	private HomePage home;
	private SearchResultPage srch;
// for searching a product
	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		srch = new SearchResultPage(driver);

	}

	@Given("User is on the homepage")
	public void user_is_on_the_homepage() {
		setup();
		home = goToHomePage();
	}

	@When("User clicks the search button")
	public void user_clicks_the_search_button() {
		home.clicksrch();
	}

	@When("User sends the data Shirt")
	public void user_sends_the_data_shirt() {
		home.clickSearch("shirt");

	}

	@When("User clicks the search submit button")
	public void user_clicks_the_search_submit_button() {
		home.clickSearchSubmitButton();
		
	}

	@Then("User is directed to the search result page")
	public void user_is_directed_to_the_search_result_page() {

    	String expectedUrl = "https://www.ubuy.co.in/search/?q=shirt";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
	}

}
