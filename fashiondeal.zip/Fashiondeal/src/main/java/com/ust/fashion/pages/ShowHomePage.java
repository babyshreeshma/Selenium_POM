package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * This class represents a page object for the Show Home page of a web
 * application.
 */
public class ShowHomePage {
	private WebDriver driver;
	
    // WebElement declarations using @FindBy annotations
	@FindBy(xpath = "//span[normalize-space()='Sign In']")
	private WebElement signin;
	@FindBy(xpath = "//a[@href='https://fashiondeal.in/saree/']//div[@class='banner-text banner-caption']//span[contains(text(),'Sarees')]")
	private WebElement sarees;
	@FindBy(xpath = "//span[text()='Gift Certificates']")
	private WebElement gift;
	@FindBy(xpath = "//span[normalize-space()='Contact Us']")
	private WebElement contact;
	
	/**
     * Constructor for the ShowHomePage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public ShowHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	 /**
     * Click the "Sign In" link and navigate to the User Registration page.
     *
     * @return An instance of the UserRegistrationPage class.
     */
	public UserRegistrationPage clickSignInlink() {
		signin.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account Login"));
		return PageFactory.initElements(driver, UserRegistrationPage.class);
	}
	
	/**
     * Click the "Sign In" link and navigate to the User Login page.
     *
     * @return An instance of the UserLoginPage class.
     */
	public UserLoginPage clickSignInlink2() {
		signin.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account Login"));
		return PageFactory.initElements(driver, UserLoginPage.class);
	}
	
	/**
     * Click the "Sarees" link and navigate to the Purchase Product page.
     *
     * @return An instance of the PurchaseProductPage class.
     */
	public PurchaseProductPage clickSareelink() {
		sarees.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Online Shopping for Designer Sarees, Printed and Embroidery ..."));
		return PageFactory.initElements(driver, PurchaseProductPage.class);
	}
	
	/**
     * Click the "Gift Certificates" link and navigate to the Gift Purchase page.
     *
     * @return An instance of the GiftPurchasePage class.
     */
	public GiftPurchasePage clickGiftPurchaselink() {
		gift.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Purchase a Gift Certificate"));
		return PageFactory.initElements(driver, GiftPurchasePage.class);
	}
	
	/**
     * Click the "Contact Us" link and navigate to the Contact Us page.
     *
     * @return An instance of the ContactUsPage class.
     */
	public ContactUsPage clickContactUslink() {
		contact.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Contact Us"));
		return PageFactory.initElements(driver, ContactUsPage.class);
	}
	
	
}
