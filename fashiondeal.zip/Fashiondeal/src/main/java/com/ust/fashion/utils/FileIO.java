package com.ust.fashion.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileIO {
	private static Properties prop;

	/**
	 * Initializes and loads properties from a file located at the path specified by
	 * the "develop.properties" file.
	 *
	 * @return A Properties object containing the loaded properties.
	 */
	public static Properties initProperties() {
		prop = new Properties();
		try {
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\test\\resources\\develop.properties");
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}
}
