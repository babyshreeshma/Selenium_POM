package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;
/**
 * This class represents a page object for the Contact Us page of a web application.
 */
public class ContactUsPage {
	private WebDriver driver;
	WebDriverWait wait;
	 // Constant for the expected page title
	public static final String title = "Contact Us";
	
	/**
     * Constructor for the ContactUsPage class.
     *
     * @param driver The WebDriver instance to use for interacting with the page.
     */
	public ContactUsPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		PageFactory.initElements(driver, this);
	}
	
	// WebElement declarations using @FindBy annotations
    // ...
	@FindBy(xpath = "//input[@id='field-20-1-1']")
	private WebElement name;
	@FindBy(xpath = "//input[@id='field-20-1-2']")
	private WebElement email;
	@FindBy(xpath = "//textarea[@id='field-20-1-4']")
	private WebElement msg;
	@FindBy(xpath = "//select[@id='field-20-1-3']")
	private WebElement drop;
	@FindBy(xpath = "//span[normalize-space()='Submit']")
	private WebElement sbm;
	@FindBy(xpath = "//div[normalize-space()='E-Mail Address does not appear to be valid!']")
	private WebElement invmail;
	@FindBy(xpath = "//div[@class='text-danger']")
	private WebElement invmail2;
	@FindBy(xpath = "//div[@class='text-danger'][1]")
	private WebElement namenp;
	@FindBy(xpath = "//div[@class='text-danger'][2]")
	private WebElement mailnp;
	@FindBy(xpath = "//div[@class='text-danger'][3]")
	private WebElement depnp;
	@FindBy(xpath = "//div[@class='text-danger'][4]")
	private WebElement msgnp;
	
	/**
     * Enter a name into the "Name" field.
     *
     * @param iname The name to be entered.
     */
	public void entername(String iname) {
		name.sendKeys(iname);
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	
	/**
     * Enter an email into the "Email" field.
     *
     * @param iemail The email to be entered.
     */
	public void enteremail(String iemail) {
		email.sendKeys(iemail);
	}

	 /**
     * Enter a message into the message field.
     *
     * @param imsg The message to be entered.
     */
	public void entermsg(String imsg) {
		msg.sendKeys(imsg);
	}
	
	/**
     * Click the dropdown to select a department.
     */
	public void dropdownclick() {
		DriverUtils.dropDownHandling(drop, "Inquiry");
	}
	
	/**
     * Click the "Submit" button.
     */
	public void submit() {
		sbm.click();
	}
	
	/**
     * Get the current URL of the web page.
     *
     * @return The current URL.
     */
	public String getcurrentUrl() {
		return driver.getCurrentUrl();
	}
	
	/**
     * Get the WebDriver instance associated with this page.
     *
     * @return The WebDriver instance.
     */
	public WebDriver returnDriver() {
		return driver;
	}

	/**
     * Get the text of the alert message.
     *
     * @return The text of the alert message.
     */
	public String alertMsg() {
		return DriverUtils.closeAlertAndGetItsText(returnDriver(), true);
	}
	
	/**
     * Get the text of the invalid email message.
     *
     * @return The text of the invalid email message.
     */
	public String invalidemailmsg() {
		return DriverUtils.getText(invmail2);
	}
	
	/**
     * Get the text of the name validation message.
     *
     * @return The text of the name validation message.
     */
	public String noname() {
		return DriverUtils.getText(namenp);
	}

	/**
     * Get the text of the email validation message.
     *
     * @return The text of the email validation message.
     */
	public String nomail() {
		return DriverUtils.getText(mailnp);
	}

	/**
     * Get the text of the department validation message.
     *
     * @return The text of the department validation message.
     */
	public String nodep() {
		return DriverUtils.getText(depnp);
	}

	/**
     * Get the text of the message validation message.
     *
     * @return The text of the message validation message.
     */
	public String nomsg() {
		return DriverUtils.getText(msgnp);
	}

}
