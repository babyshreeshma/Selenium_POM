package com.ust.fashion.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.fashion.base.DriverUtils;

/**
 * This class represents a page object for the Gift Purchase page of a web
 * application.
 */
public class GiftPurchasePage {
	private static WebDriver driver;
	WebDriverWait wait;

	/**
	 * Constructor for the GiftPurchasePage class.
	 *
	 * @param driver The WebDriver instance to use for interacting with the page.
	 */
	public GiftPurchasePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}

	// WebElement declarations using @FindBy annotations
	// ...
	@FindBy(id = "input-to-name")
	private WebElement recpname;

	@FindBy(id = "input-to-email")
	private WebElement recpemail;

	@FindBy(id = "input-from-name")
	private WebElement name;

	@FindBy(id = "input-from-email")
	private WebElement email;

	@FindBy(xpath = "//input[@value='7']")
	private WebElement theme;

	@FindBy(xpath = "//div[@class='pull-right']//input[@name='agree']")
	private WebElement agree;

	@FindBy(xpath = "//div[@id='account-voucher']//div[@class='alert alert-danger alert-dismissible']")
	private WebElement errmsg;

	@FindBy(xpath = "//button[@value='Continue']")
	private WebElement continue1;

	@FindBy(xpath = "//a[@class='btn btn-primary']")
	private WebElement continue2;

	@FindBy(xpath = "//button[@class='btn btn-danger']")
	private WebElement remove;

	@FindBy(xpath = "/html/body/div[4]/div/div/div/div/div/a")
	private WebElement continue3;

	@FindBy(xpath = "//a[@class='btn btn-default']")
	private WebElement continueShop;

	/**
	 * Input the recipient's name into the "To Name" field.
	 *
	 * @param rname The recipient's name to be entered.
	 */
	public void inputRecpName(String rname) {
		recpname.sendKeys(rname);
	}

	/**
	 * Input the recipient's email into the "To Email" field.
	 *
	 * @param remail The recipient's email to be entered.
	 */
	public void inputRecpEmail(String remail) {
		recpemail.sendKeys(remail);
	}

	/**
	 * Input the sender's name into the "From Name" field.
	 *
	 * @param iname The sender's name to be entered.
	 */
	public void inputName(String iname) {
		name.sendKeys(iname);
	}

	/**
	 * Input the sender's email into the "From Email" field.
	 *
	 * @param iemail The sender's email to be entered.
	 */
	public void inputEmail(String iemail) {
		email.sendKeys(iemail);
	}

	// Methods for interacting with page elements
	// ...
	public void themeClick() {
		theme.click();
	}

	/**
	 * Click the "Agree" checkbox.
	 */
	public void agreeClick() {
		agree.click();
	}

	/**
	 * Get the text of the error message element.
	 *
	 * @return The text of the error message.
	 */
	public String errorMsgText() {
		return DriverUtils.getText(errmsg);
	}

	/**
	 * Click the "Continue" button.
	 */
	public void contClick() {
		continue1.click();
	}

	/**
	 * Click the "Continue" button to proceed.
	 */
	public void contClick1() {
		continue2.click();
	}

	public void removeClick() {
		remove.click();
	}

	/**
	 * Click the "Continue Shopping" button.
	 */
	public void contClick2() {
		continue3.click();
	}

	/**
	 * Get the current URL of the web page.
	 *
	 * @return The current URL.
	 */
	public String getBaseUrl() {
		return driver.getCurrentUrl();
	}

	/**
	 * Get the WebDriver instance associated with this page.
	 *
	 * @return The WebDriver instance.
	 */
	public WebDriver returndriver() {
		return driver;
	}
}
