package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.ust.fashion.base.BaseTest;
import com.ust.fashion.base.DriverUtils;
import com.ust.fashion.pages.ShowHomePage;
import com.ust.fashion.pages.UserLoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


/**
 * This class represents the login steps for a test scenario.
 * It includes methods to navigate to a website, access the sign-in page,
 * retrieve page titles, and interact with login-related elements.
 */
public class LoginSteps extends BaseTest {

	public static WebDriver driver;
	public ShowHomePage home;
	public String title;
	public String forgot;
	public String loginbutton;
	
	/**
     * Navigates to the website.
     */
	@Given("the user navigates to the website")
	public void the_user_navigates_to_the_website() {
		driver=setup();
		home = goToHomePage();
	}
	
	 /**
     * Goes to the sign-in page.
     */
	@When("the user goes to the signin page")
	public void the_user_goes_to_the_signin_page() {
		home.clickSignInlink2();
	}
	
	/**
     * Retrieves the title of the page.
     */
	@Then("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		UserLoginPage user = new UserLoginPage(driver);
		title = user.getLoginTitle();
		System.out.println(title);
	}
	
	/**
     * Validates that the page title matches the expected title.
     *
     * @param string The expected page title.
     */
	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		title = user.getLoginTitle();
		Assert.assertEquals(title, string);
	}
	
	/**
     * Validates the presence of a specific button.
     *
     * @param string The expected button text.
     */
	@Then("{string} button should be displayed")
	public void link_should_be_displayed(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		loginbutton = user.getLoginButtonText();
		Assert.assertEquals(loginbutton, string);
	}
	
	/**
     * Validates the presence of a specific link.
     *
     * @param string The expected link text.
     */
	@Then("{string} link should be displayed")
	public void  button_should_be_displayed(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		forgot = user.getforgotPasswordText();
		Assert.assertEquals(forgot, string);
	}
	
	 /**
     * Enters the provided E-Mail Address.
     *
     * @param string The E-Mail Address to enter.
     */
	@When("enters their E-Mail Address as {string}")
	public void enters_their_e_mail_address_as(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		user.inputEmail(string);
	}
	
	/**
     * Enters the provided Password.
     *
     * @param string The Password to enter.
     */
	@When("enters their Password as {string}")
	public void enters_their_password_as(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		user.inputPassword(string);
	}
	
	 /**
     * Clicks on a specific button.
     *
     * @param string The button text to click.
     */
	@When("clicks on the {string} button")
	public void clicks_on_the_button(String string) {
		UserLoginPage user = new UserLoginPage(driver);
		user.clickLogin();
	}

}
