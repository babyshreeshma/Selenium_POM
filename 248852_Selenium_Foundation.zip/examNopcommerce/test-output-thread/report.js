$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"257e081f-1f49-4528-a743-29e8ece2a597","feature":"Login page feature","scenario":"Login with correct credentials","start":1692945675647,"group":1,"content":"","tags":"","end":1692945681542,"className":"passed"},{"id":"5fe1adab-6843-410e-a6b6-595f4053cf5b","feature":"Login page feature","scenario":"Login page title","start":1692945668075,"group":1,"content":"","tags":"","end":1692945675629,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});