package testCases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;

import Base.BaseUI;
import POM.MainFile;
import Utility.ExcelUtility;
import Utility.ExcelUtility2;

//Contains test cases
@Listeners(Utility.SampleListener.class)
public class MainFileTest extends BaseUI {
	WebDriver driver;
	MainFile cont;
	String[][] data;

	// Method for calling the browser
	@BeforeMethod
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	// Method to get the value from excel sheet
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = ExcelUtility.testdata();
		return data;
	}

	@DataProvider(name = "testdata1")
	public Object[][] testdata1() {
		data = ExcelUtility2.testdata();
		return data;
	}

	// Test case for testing the registration feature of the application
	@Test(priority = 1, dataProvider = "testdata1")
	public void registerTest(String firstname, String lastname, String mail, String password, String confPass) {
		MainFile obj = new MainFile(driver);
		obj.Register1();
		obj.FirstName(firstname);
		obj.LastName(lastname);
		obj.Email1(mail);
		obj.Password1(password);
		obj.confirmPas(confPass);
		obj.Register();

		logger.log(Status.INFO, "Successfull registration");

	}

	// Method to perform login operations
	@Test(priority = 2, dataProvider = "testData")
	public void loginTest(String email, String password) {
		String link = "https://demo.nopcommerce.com/";
		driver.get(link);

		MainFile obj = new MainFile(driver);
		obj.login();
		obj.Email(email);
		obj.password(password);
		obj.submit();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(link.contains("https://demo.nopcommerce.com/"));
		});

		String er = obj.errorm();
		if ((email.equals("IncorrectUser"))) {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						er.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else if (password.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						er.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(link.contains("https://demo.nopcommerce.com/"));
			});

		}

		logger.log(Status.INFO, "Successfull login test");

	}

	// Test case for testing the navigation of the electronics button clicking
	// operation
	@Test(priority = 3)
	public void electronicsTest() {
		MainFile obj = new MainFile(driver);
		// Click on the a computer
		System.out.println("Clicking on the account button...");
		obj.clickElectronics();
		// Verify that the user is redirected to the computer page
		String expectedUrl = "https://demo.nopcommerce.com/electronics";
		String actualUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});
		logger.log(Status.INFO, "Successfull electronics page redirection");
	}

	// Test case for testing the searching operation of the application
	@Test(priority = 4)
	public void searchTest() {
		MainFile obj = new MainFile(driver);
		String text = "Nikon";
		obj.sendtextSearch(text);
		obj.clickSrchbtn();
		String expectedUrl = "https://demo.nopcommerce.com/search?q=Nikon";
		String actualUrl = driver.getCurrentUrl();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		Boolean element = wait.until(ExpectedConditions.urlContains(text));
		// WebElement element=wait.until(ExpectedConditions.urlToBe("")))
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});
		logger.log(Status.INFO, "Successfull search operation");
	}
}
