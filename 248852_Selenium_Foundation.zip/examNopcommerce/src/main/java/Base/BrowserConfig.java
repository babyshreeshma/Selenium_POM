package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfig {

	static WebDriver driver;
	// To open the edge
	public static WebDriver getBrowser() {
		/*
		 * for the chrome ChromeOptions option=new ChromeOptions();
		 * option.addArguments("--disable-notifications");
		 * option.addArguments("--remote-allow-origins=*");
		 * 
		 */

		driver = new EdgeDriver();
		// To maximize the window
		driver.manage().window().maximize();
		return driver;

	}
}
