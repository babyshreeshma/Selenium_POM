package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;

//The MainFile consists of locators of the webelements and it is implemented using pagefactory
public class MainFile extends BaseUI {
	WebDriver driver;

	public MainFile(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// locators
	@FindBy(xpath = "//div[@class='header-menu']//ul[contains(@class,'notmobile')]//a[@href='/computers']")
	WebElement computer;

	@FindBy(xpath = "//div[@class='header-menu']//ul[contains(@class,'notmobile')]//a[@href='/electronics']")
	WebElement electroni;

	@FindBy(xpath = "/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
	WebElement Login;

	@FindBy(id = "Email")
	WebElement Email;

	@FindBy(id = "Password")
	WebElement Password;

	@FindBy(xpath = "//button[@class='button-1 login-button']")
	WebElement submit;

	@FindBy(id = "Email-error")
	WebElement errorm;

	@FindBy(id = "FirstName")
	WebElement FirstName;

	@FindBy(id = "LastName")
	WebElement LastName;

	@FindBy(id = "Email")
	WebElement Email1;

	@FindBy(id = "Password")
	WebElement Password1;

	@FindBy(id = "ConfirmPassword")
	WebElement ConfirmPassword;

	@FindBy(id = "register-button")
	WebElement register;

	@FindBy(xpath = "//a[text()='Register']")
	WebElement reg1;

	@FindBy(id = "small-searchterms")
	WebElement search;

	@FindBy(xpath = "//button[contains(@class,'button-1')]")
	WebElement srchbtn;

	// Methods to click,send text,get title..
	public void clickComputer() {
		clickOn(computer);
	}

	public void clickElectronics() {
		clickOn(electroni);
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public void login() {
		clickOn(Login);
	}

	public void Email(String email) {
		sendtext(Email, email);
	}

	public void password(String uname) {
		sendtext(Password, uname);
	}

	public void submit() {
		clickOn(submit);
	}

	public String errorm() {

		return rettext(errorm);
	}

	public void FirstName(String fname) {
		sendtext(FirstName, fname);
	}

	public void Email1(String email) {
		sendtext(Email1, email);
	}

	public void Password1(String pwd) {
		sendtext(Password1, pwd);
	}

	public void LastName(String lname) {
		sendtext(LastName, lname);
	}

	public void confirmPas(String cpas) {
		sendtext(ConfirmPassword, cpas);
	}

	public void Register() {
		clickOn(register);
	}

	public void Register1() {
		clickOn(reg1);
	}

	public void sendtextSearch(String text) {
		sendtext(search, text);
	}

	public void clickSrchbtn() {
		clickOn(srchbtn);
	}

}
