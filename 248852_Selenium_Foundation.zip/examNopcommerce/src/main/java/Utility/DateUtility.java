package Utility;

import java.text.SimpleDateFormat;
import java.util.Date;

//for the timestamp
public class DateUtility {
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

}
