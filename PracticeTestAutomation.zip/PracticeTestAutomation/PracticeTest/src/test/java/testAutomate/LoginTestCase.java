package testAutomate;

import org.testng.annotations.Test;

import java.time.Duration;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.Login;
import utilities.ExcelUtilities;

@Listeners(utilities.SampleListener.class)
public class LoginTestCase extends BaseUI {
	WebDriver driver;
	Login login;
	// private By practice;

	@BeforeMethod

	public void setup() {
		driver = invokeBrowser();
		openBrowser("applicationURL");
		login = new Login(driver);
		login.clickPractice();
		// login.clickLoginpage();
	}

	@Test
	@DataProvider(name = "testData")
	public Object[][] testData() {
		return ExcelUtilities.testdata();
	}

	@Test(dataProvider = "testData", priority=0)
	public void loginTest(String username, String password, String expected) throws InterruptedException {
//		username - The username to be used for login.
//		password - The password to be used for login.
//		expected - The expected outcome for the login attempt (e.g., error message or successful redirection).
//		throws InterruptedException - if the test encounters a thread interruption.

		login.clickLoginpage();
		login.userName(username);
		login.passWord(password);
		login.clickSubmitButton();
		if ((username.
				equals("incorrectUser")) || (password.equals("incorrectPassword"))) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(login.errorMessage).isDisplayed()).isTrue();
			});
			Assertions.assertThat(driver.findElement(login.errorMessage).getText())
					.isEqualTo("Your password is invalid!");
		} else {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.getCurrentUrl().contains("practicetestautomation.com/logged-in-successfully/"));
			});
		}
	}

	@Test(priority = 1)
	public void ExceptionTest() {
		login.clickExceptionpage();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		login.clickEdit();
		login.clear();

//	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // Changed the Duration.ofSeconds(20) to just 20
//	        WebElement editButtonElement = wait.until(ExpectedConditions.elementToBeClickable(login.editbtn));
//	        editButtonElement.click();
		String foodItem = "Burger";
		login.edit(foodItem);
		login.clickSave();
		login.clickAdd();

//		// Verify Food Name
		String actualsecondFoodName = getAttributeValueWithWait(login.text);
		System.out.println("Actual Food Name: " + actualsecondFoodName);
		String edit = "Burger";

		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualsecondFoodName).isEqualTo(edit).as("Food name is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 2)
	public void testFoodName() {

		// Create an instance of the checkout page object
		login.clickExceptionpage();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		login.clickAdd();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		// WebElement secondText =
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='row2']/input")));

		// Test data
		// String foodItem = "piZZa";
		// save food item
		login.editSecond("piZZa");
		login.clickSave2();

//		// Verify Food Name
		String actualsecondFoodName = getAttributeValueWithWait(login.secondText);
		System.out.println("Actual Food Name: " + actualsecondFoodName);
		String editSecond = "piZZa";

		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualsecondFoodName).isEqualTo(editSecond).as("Food name is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 3)
	public void testFoodRemove() {
	    login.clickExceptionpage();
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,250)", "");
	    login.clickAdd();
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='row2']/input")));

	    // Test data
	    // String foodItem = "piZZa";
	    // save food item
	    login.editSecond("piZZa");
	    login.clickSave2();
	    login.clickRemove();
	 // Verify Food Removal Message is Null
	    String actualmessage = getAttributeValueWithWait(login.secondText);
	    System.out.println("Actual message: " + actualmessage);
	    
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualmessage).isEmpty();
	    softAssertions.assertAll();
	}

//	@AfterMethod
//	public void tearDown() {
//		// Close the browser after each test method
//		driver.quit();
//	}
}
