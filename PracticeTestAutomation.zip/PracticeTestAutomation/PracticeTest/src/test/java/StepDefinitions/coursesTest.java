package StepDefinitions;

import org.junit.Assert;

import Base.BaseUI;
import POM.Login;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class coursesTest extends BaseUI{
	Login login;
	@Given("user is on home page")
	public void user_is_on_home_page() {
	    // Write code here that turns the phrase above into concrete actions
		driver = invokeBrowser();
		openBrowser("applicationURL");
		login = new Login(driver);
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    // Write code here that turns the phrase above into concrete actions
	   login.clickDirectcourse();
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitle) {
	    // Write code here that turns the phrase above into concrete actions
		String actualURL =driver.getCurrentUrl();
		String expectedURL="https://practicetestautomation.com/courses/";
		//Assert.assertEquals(actualURL, expectedURL, "URLs are not the same");
		Assert.assertEquals(actualURL, expectedURL);
	}

}
