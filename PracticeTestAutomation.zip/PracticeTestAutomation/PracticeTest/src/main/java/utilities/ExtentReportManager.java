package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Base.BaseUI;


public class ExtentReportManager extends BaseUI {
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	/********************
	 * Getting report instance for Extent Report
	 *********************/
	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + BaseUI.timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "//TestOutput//Report//" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "production");
		extent.setSystemInfo("User Name", "Anna");
		spark.config().setDocumentTitle("Swag Labs - Project");
		spark.config().setReportName("Swag Labs");
		spark.config().setTheme(Theme.DARK);
		return extent;
	}

}
