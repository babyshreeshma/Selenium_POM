$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"a00d61be-a684-4e62-bf5a-aebd977cdba4","feature":"course page feature","scenario":"course page title","start":1691511174523,"group":1,"content":"","tags":"","end":1691511174575,"className":"undefined"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});