package Testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.Inventory;
import POM.Login;

public class LoginTest extends BaseUI {
	private WebDriver driver;
	String[][] data;

	@BeforeTest
	public void setUp() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	@Test(priority=0)
	public void loginTest() throws InterruptedException {
		Login login = new Login(driver);
		login.userName("standard_user");
		login.passWord("secret_sauce");
		Thread.sleep(2000);
		login.submit();	
		Inventory inv = new Inventory(driver);
		String actualURL = inv.getURL();
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(actualURL.contains("https://www.saucedemo.com/inventory.html"));

			});	
		

		}
	@Test(priority=1)
	public void Inventory() throws InterruptedException {
		Inventory invent=new Inventory(driver);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(
					driver.findElement(By.xpath("//span[@class='select_container']"))
							.isDisplayed());
		});
		invent.sort();
		Thread.sleep(2000);
		invent.sort_click();
		Thread.sleep(2000);

		invent.addto_cart1();
		String product1="Sauce Labs Onesie";
		String p1 = (String) invent.getrslt1();
		System.out.println(p1);
		SoftAssertions.assertSoftly(softAssertions -> {softAssertions.assertThat(p1.equals(product1));
		});	
		
		Thread.sleep(3000);
		invent.addto_cart2();
		String product2="Sauce Labs Bike Light";
		String p2 = (String) invent.getrslt2();
		SoftAssertions.assertSoftly(softAssertions -> {softAssertions.assertThat(p2.equals(product2));
		});	
		
		
	}
	
	@Test(priority=2)
	public void cartPage() throws InterruptedException {
		Inventory invent=new Inventory(driver);

		Thread.sleep(3000);
		invent.cart_button();
		String a=invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("https://www.saucedemo.com/cart.html"));
		});
		
		Thread.sleep(3000);
		
		
		invent.removeCart1();
		Thread.sleep(3000);
		
		invent.continue_shopping();
		String actualURL = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.contains("https://www.saucedemo.com/inventory.html"));

		});	
		
		Thread.sleep(3000);
	}
	
	@Test(priority=3)
	public void backpackPage() throws InterruptedException {
		Inventory invent=new Inventory(driver);
		invent.souce_backpack();
		String actualURL = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.contains("https://www.saucedemo.com/inventory-item.html?id=4"));

		});	
		
		Thread.sleep(3000);
		invent.souce_backpack_addcart();
		Thread.sleep(3000);
		invent.back_shopping();
		String actualURL1 = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL1.contains("https://www.saucedemo.com/inventory.html"));

		});	
		
		Thread.sleep(3000);
	}
	
	@Test(priority=4)
	public void menu() throws InterruptedException {
		Inventory invent=new Inventory(driver);
		invent.menu_click();
		Thread.sleep(3000);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("react-burger-cross-btn"))
					.isDisplayed());

		});	
		

		invent.reset_click();
		Thread.sleep(3000);
		invent.close_click();
		Thread.sleep(2000);
		
		invent.cart_button();
		String actualURL1 = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL1.contains("https://www.saucedemo.com/cart.html"));

		});	
		
		Thread.sleep(2000);
		invent.continue_shopping();
		String actualURL2 = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL2.contains("https://www.saucedemo.com/inventory.html"));

		});	
		
		Thread.sleep(2000);
		
		invent.menu_click();
		Thread.sleep(2000);
		
		invent.logout_click();
		String actualURL3 = invent.getURL();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL3.contains("https://www.saucedemo.com/"));

		});	
		
	}
}
