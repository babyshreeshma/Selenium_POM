package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Base.BaseUI;

public class Inventory extends BaseUI{
	WebDriver driver;
	public Inventory(WebDriver driver) {
		this.driver = driver;
	}
	
	By sort_ = getlocator("sort_xpath");
	By sort_click_=getlocator("sortclick_xpath");
	
	By rslt1 = getlocator("rslt1_xpath");
	By rslt2 = getlocator("rslt2_xpath");
	By add_cart1=getlocator("add_cart_onesie_name");
	By add_cart2=getlocator("add_cart_light_name");
	By cart_btn=getlocator("cart_button_xpath");
	By remove_cart1=getlocator("remove_cart_onesie_xpath");
	By continue_shop=getlocator("continue_shopping_id");
	By Sauce_Backpack=getlocator("Sauce_Backpack_id");
	By Sauce_Backpack_add=getlocator("Sauce_Backpack_addcart_id");
	By back_to_shopping=getlocator("backto_shopping_id");
	By menu=getlocator("menu_id");
	By menu_close=getlocator("menu_close_id");
	By reset=getlocator("reset_linkText");
	By close=getlocator("close_id");
	By logout=getlocator("logout_linkText");
	
	public String getURL() {
		String url = driver.getCurrentUrl();
		return url;
	}
	public void sort() {
		clickOn(sort_);
	}

	public void sort_click() {
		clickOn(sort_click_);
	}
	
	public String getrslt1() {
		return gettext(rslt1);
	}
	
	public String getrslt2() {
		return gettext(rslt2);

	}
	public void addto_cart1() {
		clickOn(add_cart1);
	}
	public void addto_cart2() {
		clickOn(add_cart2);
	}
	public void cart_button() {
		clickOn(cart_btn);
	}
	public void removeCart1() {
		clickOn(remove_cart1);
	}
	public void continue_shopping() {
		clickOn(continue_shop);
	}
	public void souce_backpack() {
		clickOn(Sauce_Backpack);
	}
	public void souce_backpack_addcart() {
		clickOn(Sauce_Backpack_add);
	}
	
	public void back_shopping() {
		clickOn(back_to_shopping);
	}
	public void menu_click() {
		clickOn(menu);
	}
	public void menu_close_() {
		clickOn(menu_close);
	}
//	public void about_click() {
//		clickOn(about);
//	}
	public void reset_click() {
		clickOn(reset);
	}
	public void close_click() {
		clickOn(close);
	}
	public void logout_click() {
		clickOn(logout);
	}
}
